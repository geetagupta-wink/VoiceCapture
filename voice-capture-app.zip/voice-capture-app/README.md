# Voice Capture App

A browser-based voice capture app with real-time VAD (Voice Activity Detection), fan noise rejection, and audio upload to a backend.

## Features
- Real-time waveform visualizer
- RMS + ZCR based voice activity detection
- Fan / AC noise rejection
- Requires ≥ 10s of clean speech (max 15s session)
- Progress bars for voice collected + session time
- Segment timeline showing voice / noise / silence
- Sends audio as `multipart/form-data` to `/api/voice/upload`

## Deploy to Vercel

### Option A — Vercel CLI (recommended)
```bash
npm i -g vercel
cd voice-capture-app
vercel
```
Follow the prompts. On first run it will ask you to log in and link a project.

### Option B — Vercel Dashboard (drag & drop)
1. Go to https://vercel.com/new
2. Choose **"Deploy without a Git repository"** → **"Browse"**
3. Upload the entire `voice-capture-app` folder
4. Click **Deploy**

### Option C — GitHub
1. Push this folder to a GitHub repo
2. Go to https://vercel.com/new → Import Git Repository
3. Select the repo → Deploy

## Backend
The Send button POSTs to `/api/voice/upload` with:
- `audio` — WebM audio blob (16kHz)
- `duration` — seconds of clean voice (string)
- `sampleRate` — "16000"

Add your backend route at that path (Vercel serverless, Express, FastAPI, etc.).

## Local dev
```bash
npx serve .
# or
python3 -m http.server 8080
```
Open http://localhost:8080 — microphone requires HTTPS or localhost.
